async function buscar(){
    //captura o id que o usuario digitar
    const id = document.getElementById('id_personagem').value

    //concatenar com a url - fetch
    const resposta = await fetch(`https://rickandmortyapi.com/api/character/${id}`)
    
    //ler dados em json
    const dados = await resposta.json();
        

    //mostro pro usuario
    document.getElementById('resultado').innerHTML=`
    <h1>${dados.name}</h1>
    <img src="${dados.image}" width="150px">
    <h2>${dados.status}</h2>
    
    `
     
    
}